#!/bin/bash

# Function to check if the current server is part of an RAC
check_rac_status() {
    # Extract hostname and convert to lowercase
    local hostname=$(hostname | tr '[:upper:]' '[:lower:]')

    # Default value for IS_THIS_RAC_DB
    local is_this_rac_db="NO"

    # Read through the file
    while IFS=, read -r server rac_flag
    do
        # Convert server name to lowercase for case-insensitive comparison
        local server_lower=$(echo "$server" | tr '[:upper:]' '[:lower:]')

        if [[ "$server_lower" == "$hostname" ]]; then
            if [[ "$rac_flag" == "Y" ]]; then
                is_this_rac_db="YES"
            fi
            break
        fi
    done < "$FILE_PATH"

    echo $is_this_rac_db
}


export ORACLE_BASE=/u02/app/oracle
#export ORACLE_HOME=/u02/app/oracle/product/19.3.0/db_1
export ORACLE_HOME=/u02/app/oracle/product/19.3.0/db_1
export LD_LIBRARY_PATH=${ORACLE_HOME}/lib
export PATH=$PATH:${ORACLE_HOME}/bin:${ORACLE_HOME}/OPatch


export TIMESTAMP=$(date +"%Y-%m-%d-%T")
#export PATCH_DIR=/nonproddatabase/oracle/software/PSU/OCT2025/$(hostname)
export PATCH_DIR=/u02/software/PSU/OCT2025/$(hostname)
export PATCH_LOG_DIR=${PATCH_DIR}/logs


# File path to the server list
export FILE_PATH=${PATCH_DIR}/server_list.txt
# Call the function and store the result in a variable
export IS_THIS_RAC_DB=$(check_rac_status)


echo "Is this a RAC instance: "${IS_THIS_RAC_DB}

export COMBO_PATCH_NUMBER=38273558
export GI_DB_HOME_PATCH_NUMBER=38298204
export DB_OJVM_PATCH_NUMBER=38194382

export BUGNO=${GI_DB_HOME_PATCH_NUMBER}
export OCW_BUG=38322923
export ACFS_BUG=38311528
export TOMCAT_BUG=38380425
export DBWLM_BUG=36758186
export DBRU_BUG=38291812
export JDK_PATCH=38245243


export ROLLBACK_PATCH_LIST="rollback_patch_list.txt"
export ONEOFF_PATCH_LIST="oneoff_oracle_home_patch_list.txt"


#export PATH=$ORACLE_HOME/perl/bin:$PATH
#export PERL5LIB=$ORACLE_HOME/perl/lib

